#!/bin/bash

OUTPUT_BASE_DIR="/home/grads/wvh5193/530hw3/output"
M5OUT_SOURCE_DIR="/home/grads/wvh5193/530hw3/m5out"


mkdir -p "${OUTPUT_BASE_DIR}"

declare -a RUN_COMMANDS=(
    "run_3_S_2G_1600" 
    "run_4_S_2.5G_1600" 
    "run_5_S_3G_1600" 
    "run_6_M_1G_1600" 
    "run_7_M_1.5G_1600" 
    "run_8_M_2G_1600" 
)


for RUN_CMD in "${RUN_COMMANDS[@]}"; do
    # Execute make compile
    echo "Executing: make compile"
    make compile
    if [ $? -ne 0 ]; then
        echo "Error encountered during 'make compile'. Exiting script."
        exit 1
    fi
    
    echo "Executing: make ${RUN_CMD}"
    make ${RUN_CMD}
    if [ $? -ne 0 ]; then
        echo "Error encountered during 'make ${RUN_CMD}'. Exiting script."
        exit 1
    fi
    echo "Finished: make ${RUN_CMD}"

    echo "Copying m5out to ${OUTPUT_BASE_DIR}/${RUN_CMD}"
    cp -r "${M5OUT_SOURCE_DIR}" "${OUTPUT_BASE_DIR}/${RUN_CMD}"
    if [ $? -ne 0 ]; then
        echo "Error encountered while copying m5out. Exiting script."
        exit 1
    fi


done
