#define IN_SIZE 1024
#define TEMP_IN "temp_1024"
#define POWER_IN "power_1024"
#define MULTIPLIER 4
#define TEMP_OUT "temp_4096"
#define POWER_OUT "power_4096"