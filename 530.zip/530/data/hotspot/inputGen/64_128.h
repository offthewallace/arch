#define IN_SIZE 64
#define TEMP_IN "temp_64"
#define POWER_IN "power_64"
#define MULTIPLIER 2
#define TEMP_OUT "temp_128"
#define POWER_OUT "power_128"